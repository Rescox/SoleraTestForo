import './App.css';
import {BrowserRouter as Router, Route, Routes} from "react-router-dom";
import HeaderForo  from './components/HeaderForo';
import Vehicles  from './components/Vehicles';
import Owners  from './components/Owners';
import Claims  from './components/Claims';



import Welcome from './components/Welcome'
function App() {
 

    return (
      <div className="App">
        <Router>
      
      <HeaderForo/>
        <Routes>
          <Route exact path='/'  element={<Welcome/>}></Route>
          <Route exact path='/Vehicles'  element={<Vehicles/>}></Route>
          <Route exact path='/Owners'  element={<Owners/>}></Route>
          <Route exact path='/Claims'  element={<Claims/>}></Route>



        </Routes>

        </Router>
      </div>
    );
  }

export default App;
