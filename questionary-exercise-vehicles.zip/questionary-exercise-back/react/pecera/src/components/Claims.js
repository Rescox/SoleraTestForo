import axios from 'axios'
import React from 'react';


const USERS_REST_API_URL = "https://localhost:5001/api/claim/getallclaims"

class Claims extends React.Component{
    constructor(props) { 
        super(props);

        this.state = {
            claims:[]
        }
    }
    getClaims = () => {
        return axios.get(USERS_REST_API_URL);
    }

    componentDidMount() {
        this.getClaims().then((response) => {
            console.log(response.data)
            this.setState({ claims: response.data })
            console.log(this.state.claims)
        });
    }

    render() {
        return (
            <div className='welcomeH1'>
                <table className='customTable1'>
                    <thead>
                        <tr>
                            <td><strong>Description</strong></td>
                            <td><strong>Status</strong></td>
                            <td><strong>Date</strong></td>
                            <td><strong>Year</strong></td>


                        </tr>
                    </thead>
                    <tbody>
                    {
                            this.state.claims.map(
                                claim =>
                            <tr key = {claim.id}>    
                                <td>{claim.description}</td>
                                <td>{claim.status}</td>
                                <td>{claim.date}</td>
                            </tr>
                            )
                        }
                    </tbody>
                </table>            
            </div>      
        )
    }};   

export default Claims;