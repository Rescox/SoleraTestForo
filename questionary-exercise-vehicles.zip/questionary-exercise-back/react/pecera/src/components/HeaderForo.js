
import '../App.css';
import './HeaderForo.css';


function HeaderForo() {


  
    return (
        <div className="header">
            <div className = "Header">
                <h2 id = "Marcaweb">Solera .Net Application</h2>
                <div className="listOption">
                    <a className='singleItem' href = "http://localhost:3000/Vehicles"><p>Vehicles</p></a>
                    <a className='singleItem' href = "http://localhost:3000/Owners"><p>Owners</p></a>
                    <a className='singleItem' href = "http://localhost:3000/Claims"><p>Claims</p></a>

                </div>       
            </div>
        </div>
        )
    
}

export default HeaderForo;