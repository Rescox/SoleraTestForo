import axios from 'axios'
import React from 'react';


const USERS_REST_API_URL = "https://localhost:5001/api/vehicle/getallvehicles"

class Vehicles extends React.Component{
    constructor(props) { 
        super(props);

        this.state = {
            vehicles:[]
        }
    }
    getVehicles = () => {
        return axios.get(USERS_REST_API_URL);
    }

    componentDidMount() {
        this.getVehicles().then((response) => {
            console.log(response.data)
            this.setState({ vehicles: response.data })
            console.log(this.state.vehicles)
        });
    }

    render() {
        return (
            <div className='welcomeH1'>
                <table className='customTable1'>
                    <thead>
                        <tr>
                            <td><strong>Brand</strong></td>
                            <td><strong>Vin</strong></td>
                            <td><strong>Color</strong></td>
                            <td><strong>Year</strong></td>

                        </tr>
                    </thead>
                    <tbody>
                    {
                            this.state.vehicles.map(
                                vehicle =>
                            <tr key = {vehicle.id}>    
                                <td>{vehicle.brand}</td>
                                <td>{vehicle.vin}</td>
                                <td>{vehicle.color}</td>
                                <td>{vehicle.year}</td>
                            </tr>
                            )
                        }
                    </tbody>
                </table>            
            </div>      
        )
    }};   

export default Vehicles;