import axios from 'axios'
import React from 'react';


const USERS_REST_API_URL = "https://localhost:5001/api/owner/getallowners"

class Owners extends React.Component{
    constructor(props) { 
        super(props);

        this.state = {
            owners:[]
        }
    }
    getOwners = () => {
        return axios.get(USERS_REST_API_URL);
    }

    componentDidMount() {
        this.getOwners().then((response) => {
            console.log(response.data)
            this.setState({ owners: response.data })
            console.log(this.state.owners)
        });
    }

    render() {
        return (
            <div className='welcomeH1'>
                <table className='customTable1'>
                    <thead>
                        <tr>
                            <td><strong>First name</strong></td>
                            <td><strong>Last name</strong></td>
                            <td><strong>Driver License</strong></td>

                        </tr>
                    </thead>
                    <tbody>
                    {
                            this.state.owners.map(
                                owner =>
                            <tr key = {owner.id}>    
                                <td>{owner.first_name}</td>
                                <td>{owner.last_name}</td>
                                <td>{owner.driver_license}</td>
                            </tr>
                            )
                        }
                    </tbody>
                </table>            
            </div>      
        )
    }};   

export default Owners;