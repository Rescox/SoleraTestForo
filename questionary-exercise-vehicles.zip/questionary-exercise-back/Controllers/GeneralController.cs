﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using questionary_exercise_back.Models;
using questionary_exercise_back.Repositories;

namespace questionary_exercise_back.Controllers
{

    [Route("api/owner")]
    [ApiController]
    public class OwnerController : ControllerBase
    {
        private readonly iOwnerRepository _ownerRepository;
        public OwnerController(iOwnerRepository ownerRepository)
        {
            _ownerRepository = ownerRepository;
        }

      

        [HttpGet("getAllOwners")]
        public async Task<IActionResult> GetAllOwners()
        {
            var owner = await _ownerRepository.GetAllOwners();
            Console.WriteLine(owner);
            return Ok(owner);
        


        }
        [HttpGet("getOwnerById/{id}")]
        public async Task<IActionResult> GetOwnerId(int id)
        {
            return Ok(await _ownerRepository.GetOwner(id));
        }

        [HttpPost("createOwner/")]
        public async Task<IActionResult> CreateOwner([FromBody] Owner owner)
        {
            if (owner == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var created = await _ownerRepository.AddOwner(owner);
            return Created("created", created);
        }
    }



    [Route("api/vehicle")]
    [ApiController]
    public class VehicleController : ControllerBase
    {
        private readonly iVehicleRepository _vehicleRepository;
        public VehicleController(iVehicleRepository vehicleRepository)
        {
            _vehicleRepository = vehicleRepository;
        }

        [HttpGet("getAllVehicles")]
        public async Task<IActionResult> GetAllVehicles()
        {
            var vehicle = await _vehicleRepository.GetAllVehicles();
            Console.WriteLine(vehicle);
            return Ok(vehicle);
        }

        [HttpGet("getVehicleById/{id}")]
        public async Task<IActionResult> GetVehicle(int id)
        {
            return Ok(await _vehicleRepository.GetVehicle(id));
        }

        [HttpPost("createVehicle/")]
        public async Task<IActionResult> CreateVehicle([FromBody] Vehicle vehicle)
        {
            if (vehicle == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var created = await _vehicleRepository.AddVehicle(vehicle);
            return Created("created", created);
        }
    }


    [Route("api/claim")]
    [ApiController]
    public class ClaimController : ControllerBase
    {
        private readonly iClaimRepository _claimRepository;
        public ClaimController(iClaimRepository claimRepository)
        {
            _claimRepository = claimRepository;
        }

        [HttpGet("getAllClaims")]
        public async Task<IActionResult> GetAllClaims()
        {
            var claim = await _claimRepository.GetAllClaims();
            Console.WriteLine(claim);
            return Ok(claim);
        }

        [HttpGet("getClaimById/{id}")]
        public async Task<IActionResult> GetClaim(int id)
        {
            return Ok(await _claimRepository.GetClaim(id));
        }

        [HttpPost("createClaim/")]
        public async Task<IActionResult> CreateClaim([FromBody] Claim claim)
        {
            if (claim == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var created = await _claimRepository.AddClaim(claim);
            return Created("created", created);
        }
    }
}
