using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;
using questionary_exercise_back.Repositories;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var mySQLConfiguration = new MySQLConfiguration(builder.Configuration.GetConnectionString("MySqlConnection"));
builder.Services.AddSingleton(mySQLConfiguration);
//Para usar una misma conexi�n existente en vez de generar una nueva para cada vez que se quiera usar la base de datos
//se usar�a el c�digo de la siguiente linea en lugar del de las 2 lineas de arriba.
//builder.Services.AddSingleton(new MySqlConnection(builder.Configuration.GetConnectionString("MySqlConnection")));
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

builder.Services.AddScoped<iOwnerRepository, OwnerRepository>();
builder.Services.AddScoped<iVehicleRepository, VehicleRepository>();
builder.Services.AddScoped<iClaimRepository, ClaimRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors(x => x.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(origin=>true).AllowCredentials() );
app.UseAuthorization();

app.MapControllers();

app.Run();
