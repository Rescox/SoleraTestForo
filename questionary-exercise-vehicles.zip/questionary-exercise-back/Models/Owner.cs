﻿namespace questionary_exercise_back.Models
{
    public class Owner
    {
        public int Id { get; set; }
        public string first_name { get; set; }

        public string last_name { get; set; }
        public string driver_license { get; set; }
    }
}
