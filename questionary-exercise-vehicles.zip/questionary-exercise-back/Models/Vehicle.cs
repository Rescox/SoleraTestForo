namespace questionary_exercise_back.Models
{

	public class Vehicle
{
	public int Id { get; set; }
	public string Brand { get; set; }
	public string Vin { get; set; }
	public string Color { get; set; }
	public string Year { get; set; }

}
}
