using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public interface iClaimRepository
    {
        Task<IEnumerable<Claim>> GetAllClaims();
        Task<Claim> GetClaim(int id);
        Task<bool> AddClaim(Claim item);
    }
}