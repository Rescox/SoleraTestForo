using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public interface iVehicleRepository
    {
        Task<IEnumerable<Vehicle>> GetAllVehicles();
        Task<Vehicle> GetVehicle(int id);
        Task<bool> AddVehicle(Vehicle item);
    }
}