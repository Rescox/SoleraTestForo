using Dapper;
using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
	public class OwnerRepository : iOwnerRepository
	{
		private readonly MySQLConfiguration _connectionString;
		public OwnerRepository(MySQLConfiguration connectionString)
		{
			_connectionString = connectionString;
		}
		protected MySqlConnection dbConnection()
		{
			return new MySqlConnection(_connectionString.ConnectionString);
		}

		public async Task<bool> AddOwner(Owner item)
		{
			var db = dbConnection();
			var sql = @" INSERT INTO owners(first_name, last_name, driver_license) 
                        VALUES(@first_name, @last_name, @driver_license) ";
			var result = await db.ExecuteAsync(sql, new { item.first_name, item.last_name, item.driver_license });
			return result > 0;
		}

		public Task<IEnumerable<Owner>> GetAllOwners()
		{
			var db = dbConnection();
			var sql = @" SELECT * FROM owners";
			return db.QueryAsync<Owner>(sql, new { });
		}

		public Task<Owner> GetOwner(int id)
		{
			var db = dbConnection();
			var sql = @" SELECT * FROM owners WHERE id = @Id ";
			return db.QueryFirstOrDefaultAsync<Owner>(sql, new { Id = id });
		}
	}
}
