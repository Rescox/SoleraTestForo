using Dapper;
using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public class VehicleRepository : iVehicleRepository
    {
        private readonly MySQLConfiguration _connectionString;
        public VehicleRepository(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }

        public async Task<bool> AddVehicle(Vehicle item)
        {
            var db = dbConnection();
            var sql = @" INSERT INTO vehicles(brand, vin, color, year) 
                        VALUES(@Brand, @Vin, @Color, @Year) ";
            var result = await db.ExecuteAsync(sql, new { item.Brand, item.Vin, item.Color, item.Year });
            return result > 0;
        }

        public Task<IEnumerable<Vehicle>> GetAllVehicles()
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM vehicles";
            return db.QueryAsync<Vehicle>(sql, new { });
        }

        public Task<Vehicle> GetVehicle(int id)
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM vehicles WHERE id = @Id ";
            return db.QueryFirstOrDefaultAsync<Vehicle>(sql, new { Id = id });
        }
    }
}
