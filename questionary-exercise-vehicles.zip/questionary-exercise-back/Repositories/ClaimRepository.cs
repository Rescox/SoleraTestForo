using Dapper;
using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public class ClaimRepository : iClaimRepository
    {
        private readonly MySQLConfiguration _connectionString;
        public ClaimRepository(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }

        public async Task<bool> AddClaim(Claim item)
        {
            var db = dbConnection();
            var sql = @" INSERT INTO claim(description, status, date, year) 
                        VALUES(@description, @status, @date, @year) ";
            var result = await db.ExecuteAsync(sql, new { item.Description, item.Status, item.Date, item.Year });
            return result > 0;
        }

        public Task<IEnumerable<Claim>> GetAllClaims()
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM claim";
            return db.QueryAsync<Claim>(sql, new { });
        }

        public Task<Claim> GetClaim(int id)
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM claim WHERE id = @Id ";
            return db.QueryFirstOrDefaultAsync<Claim>(sql, new { Id = id });
        }
    }
}
