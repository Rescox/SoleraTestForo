using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public interface iOwnerRepository
    {
        Task<IEnumerable<Owner>> GetAllOwners();
        Task<Owner> GetOwner(int id);
        Task<bool> AddOwner(Owner item);
    }
}