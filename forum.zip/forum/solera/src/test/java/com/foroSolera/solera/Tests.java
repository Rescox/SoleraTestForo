package com.foroSolera.solera;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.foroSolera.solera.controllers.BannedWordController;
import com.foroSolera.solera.controllers.UserController;
import com.foroSolera.solera.controllers.PostController;
import com.foroSolera.solera.models.BannedWord;
import com.foroSolera.solera.models.User;
import com.foroSolera.solera.models.Post;


@SpringBootTest
class Tests {
    
    @Autowired
	UserController userController = new UserController();

    @Autowired
	BannedWordController bannedWordController = new BannedWordController();

    @Autowired
    PostController postController = new PostController();

	@Test
	public void testPost_controller_getOne() {
		Optional<Post> postOptional =  postController.findByIdPost(3);
		Post post = postOptional.get();
		//Todo todoTest = new Todo(" ","",null, false);
    	assertEquals("Test1", post.getTitle());
		assertEquals("question", post.getCategory());
	}

    @Test
	public void testPost_controller_getAll() {
		List<Post> postList =  postController.getTodos();
		Post post = postList.get(0);
		//Todo todoTest = new Todo(" ","",null, false);
    	assertEquals("Test1", post.getTitle());
		assertEquals("question", post.getCategory());
	}

    @Test
	public void testUser_controller_getAll() {
		List<User> userList =  userController.getUsers();
		User user = userList.get(0);
    	assertEquals("Hola", user.getUserMail());
		assertEquals("Nombre1", user.getUserName());
	}

    @Test
	public void testBannedWord_controller_getAll() {
		List<BannedWord> bannedWordList =  bannedWordController.getBannedwords();
		BannedWord bannedWord = bannedWordList.get(0);
    	assertEquals("cabron", bannedWord.getBannedWord());
	}

}

