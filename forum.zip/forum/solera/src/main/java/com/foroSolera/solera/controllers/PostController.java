package com.foroSolera.solera.controllers;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foroSolera.solera.models.Post;
import com.foroSolera.solera.repository.PostRepository;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/")
public class PostController {
    
    @Autowired
    private PostRepository postRepository;

    @GetMapping("posts")
    public List<Post> getTodos() {
        return this.postRepository.findAll();    
    }

    @GetMapping("posts/{category}")
    public List<Post> findByCategory(@PathVariable String category) {
        return this.postRepository.findByCategory(category);
    }

    @GetMapping("posts/one/{id}")
    public Optional<Post> findByIdPost(@PathVariable long id) {
        return this.postRepository.findById(id);
    }

    @PostMapping("posts")
    public Post SaveTodo(@RequestBody Post post) {
        return postRepository.save(post);
       }

    @DeleteMapping("posts/{id}")
    public void destroyTodo(@PathVariable Long id) {

        postRepository.deleteById(id);
    }

    

}
