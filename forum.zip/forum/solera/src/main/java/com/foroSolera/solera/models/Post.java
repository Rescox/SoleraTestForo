package com.foroSolera.solera.models;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "posts")
public class Post {


    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String postbody;
    private String category;
    private String imgurl;

   

    public Post() {
        super();

    }
    

    public Post(Long id, String title, String postbody, String category, String imgurl) {
        super();

        this.id = id;
        this.title = title;
        this.postbody = postbody;
        this.category = category;
        this.imgurl = imgurl;
    }

    public Post(String title, String postbody, String category,String imgurl) {
        super();

        this.title = title;
        this.postbody = postbody;
        this.category = category;
        this.imgurl = imgurl;
    }

    /**
     * @return Long return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return String return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return String return the postbody
     */
    public String getPostbody() {
        return postbody;
    }

    /**
     * @param postbody the postbody to set
     */
    public void setPostbody(String postbody) {
        this.postbody = postbody;
    }

    /**
     * @return String return the imgurl
     */
    public String getImgurl() {
        return imgurl;
    }

    /**
     * @param imgurl the imgurl to set
     */
    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }


    /**
     * @return String return the category
     */
    public String getCategory() {
        return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
        this.category = category;
    }

}
