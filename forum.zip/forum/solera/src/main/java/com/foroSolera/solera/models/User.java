package com.foroSolera.solera.models;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User {
	

		@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private long id;

		
		private String userName;

	    private String userMail;
	
	    private String password;


		
			

	    public User() {
	        super();
	    }


        public User(long id, String userName, String userMail, String password) {
	        
			super();
            this.setId(id);
	        this.setUserName(userName);
	        this.setUserMail(userMail);
	        this.setPassword(password);
			

			
	    }
		

	    public User(String userName, String userMail, String password) {
	        
			super();

	        this.setUserName(userName);
	        this.setUserMail(userMail);
	        this.setPassword(password);
			

			
	    }
	    /*
	    private static void checkDates(Date creationDate, Date finalizationDate) throws Exception {
			
				if(creationDate.isAfter(finalizationDate)) {
					throw new Exception("Fecha de creacion mayor que la de finalización");
				}
			}
		*/

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

		public String getUserName() {
			return userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}

		public String getUserMail() {
			return userMail;
		}

		public void setUserMail(String userMail) {
			this.userMail = userMail;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

}


