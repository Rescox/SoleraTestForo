package com.foroSolera.solera.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.PathVariable;

import com.foroSolera.solera.models.User;


public interface UserRepository extends JpaRepository<User, Long>{
    Optional<User> findByUserMail(@PathVariable String userMail);

}
