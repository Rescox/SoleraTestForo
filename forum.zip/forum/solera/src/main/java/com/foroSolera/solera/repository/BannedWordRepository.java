package com.foroSolera.solera.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.PathVariable;

import com.foroSolera.solera.models.BannedWord;


public interface BannedWordRepository extends JpaRepository<BannedWord, Long>{
}   
