package com.foroSolera.solera.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foroSolera.solera.models.BannedWord;
import com.foroSolera.solera.repository.BannedWordRepository;
import com.foroSolera.solera.repository.UserRepository;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/")

public class BannedWordController {
    
    @Autowired
    private BannedWordRepository bannedWordRepository;

    @GetMapping("bannedword")
    public List<BannedWord> getBannedwords() {
        return this.bannedWordRepository.findAll();    
    }

}

