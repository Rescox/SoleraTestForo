package com.foroSolera.solera;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.foroSolera.solera.repository.PostRepository;
import com.foroSolera.solera.repository.UserRepository;

@EnableJpaRepositories
@SpringBootApplication
public class SoleraApplication {

	@Autowired
	private PostRepository postRepository;

	@Autowired
	private UserRepository userRepository;

	public static void main(String[] args) {
		SpringApplication.run(SoleraApplication.class, args);
	}

}
