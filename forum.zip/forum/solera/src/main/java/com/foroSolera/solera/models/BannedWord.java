package com.foroSolera.solera.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "bannedword")
public class BannedWord {


    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String bannedWord;
    
    public BannedWord() {
        super();

    }
    

    public BannedWord(Long id, String bannedWord) {
        super();

        this.id = id;
        this.bannedWord = bannedWord;
    }

    public BannedWord(String word) {
        super();

        this.bannedWord = bannedWord;
    }

    /**
     * @return Long return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return String return the title
     */
    public String getBannedWord() {
        return bannedWord;
    }

    /**
     * @param word the word to set
     */
    public void setWord(String bannedWord) {
        this.bannedWord = bannedWord;
    }
}
