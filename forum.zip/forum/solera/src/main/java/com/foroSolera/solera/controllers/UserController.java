package com.foroSolera.solera.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foroSolera.solera.models.User;
import com.foroSolera.solera.repository.UserRepository;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("api/")
public class UserController {
    
    @Autowired
    private UserRepository userRepository;

    @GetMapping("users")
    public List<User> getUsers() {
        return this.userRepository.findAll();    
    }

    @GetMapping("userinformation")
    public User getUserInformation() {
        User user = new User("solera","solera@solera.com", "bootcamp2");
        return user;    
    }   

    @GetMapping("users/{email}")
    public Optional<User> findByEmail(@PathVariable String userMail) {
        return this.userRepository.findByUserMail(userMail);
    }
}

