import './App.css';
import { UserContext } from './components/context/UserContext';

import {useState, useMemo} from 'react';
import LoginForm from './components/LoginForm';
import {BrowserRouter as Router, Route, Routes} from "react-router-dom";
import HeaderForo  from './components/HeaderForo';
import FooterForo  from './components/FooterForo';
import SelectCategory  from './components/SelectCategory';
import Forum from './components/Forum'
import CreatePost from './components/CreatePost';
import Posts from './components/Posts'



import Welcome from './components/Welcome'
function App() {
  const [id, setId] = useState(localStorage.getItem('id') || 0);
  const [userName, setUserName] = useState(localStorage.getItem('userName') || '');
  const [userEmail, setUserEmail] = useState(localStorage.getItem('userEmail') || '');
  const [isLoggedIn, setIsLoggedIn] = useState(localStorage.getItem('isLoggedIn') || 'notLoggedIn');
  const providerValue = useMemo(() => ({id, setId, userName, setUserName, userEmail, setUserEmail, isLoggedIn, setIsLoggedIn}), [id, setId, userName, setUserName, userEmail, setUserEmail, isLoggedIn, setIsLoggedIn])


  if(isLoggedIn == "notLoggedIn") { 
    return (
      <div className="App">
        <Router>
      
      <UserContext.Provider value = {providerValue} >
      <HeaderForo/>
        <Routes>
          <Route exact path='/'  element={<Welcome/>}></Route>
          <Route exact path='/LoginForm'  element={<LoginForm/>}></Route>

        </Routes>
        <FooterForo/>

        </UserContext.Provider>
        </Router>
      </div>
    );
  } else {
    return (
      <div className="App">
        <Router>
      
      <UserContext.Provider value = {providerValue} >
      <HeaderForo/>
        <Routes>
          <Route exact path='/'  element={<SelectCategory/>}></Route>
          <Route exact path='/forum/:category' element={<Forum/>}></Route>
          <Route exact path="/forum/posts/:postid" element={<Posts />} />
          <Route exact path='/forum/:category/CreatePost' element ={<CreatePost/>}/>

        </Routes>
        <FooterForo/>

        </UserContext.Provider>
        </Router>
      </div>
    )
  }
}

export default App;
