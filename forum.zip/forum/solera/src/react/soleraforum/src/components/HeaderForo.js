
import '../App.css';
import './HeaderForo.css';
import { useContext } from "react";

import { UserContext } from './context/UserContext';


function HeaderForo() {
    const {userName, isLoggedIn } = useContext(UserContext);

   function handleLogout(e) {
        e.preventDefault();
        window.localStorage.clear();
        window.location.reload();
    }

    if(isLoggedIn != 'notLoggedIn') { 
        return (
            <div className="header">
                <div className = "Header">
                    <h2 id = "Marcaweb">Solera Forum</h2>
                    <div className="listOption">
                        <p className='singleItem'>{userName}</p>
                        <a className='singleItem' href = "http://localhost:3000/"><p>Index</p></a>
                        <a className='singleItem' href = "http://localhost:3000/Profile"><p>Profile</p></a>
                        <a className='singleItem' onClick={handleLogout} ><p>Logout</p></a>
                    </div>       
                </div>
            </div>
        )
    } else {
        return (
            <div className="header">
                <div className = "Header">
                    <h2 id = "Marcaweb">Solera Forum</h2>
                    <div className="aLogin">
                    <a href = "http://localhost:3000/LoginForm"><p>Login</p></a>
                    </div>       
                </div>
            </div>
        )
    }
}

export default HeaderForo;