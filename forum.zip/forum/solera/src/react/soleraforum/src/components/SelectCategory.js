import './SelectCategory.css';
import axios from 'axios';
import {Link} from 'react-router-dom';

function SelectCategory() {

  function handleClick (subject) {
    console.log(subject);
  }

  return (
    <div className="SelectCategory">
    <div class = "Category">
    <h2>Categorias</h2>
     <Link className = "postLinks" to={`/forum/question`}>Question❓</Link>
     <Link className = "postLinks" to={`/forum/suggestion`}>Suggestion📢</Link>
     <Link className = "postLinks" to={`/forum/clarification`}>Clarification✏</Link>

    </div>

</div>
  )
  }

export default SelectCategory;