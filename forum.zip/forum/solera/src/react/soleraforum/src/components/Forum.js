import './Forum.css';
import axios from 'axios';
import React,{useEffect, useState} from 'react';
import { Link, useParams } from "react-router-dom";


function Forum() {

    const [posts, setPosts] = useState([]);
    const params = useParams();
    
      

 


    const getPosts = async () => {
        const  {data}  = await axios.get("http://localhost:8080/api/posts/" + params.category);
        setPosts(data)

      };
      useEffect(() => {        
        getPosts();
      }, []);

  return (
    <div className="ForumSelected">
    <div className = "Forum">

    <div><h2>Foro</h2></div>
     
    {
        posts.map(
            post =>
                <Link className = "postLinks" to={`/forum/posts/${post.id}`}>{post.title}</Link>
        )
    }    

<Link className = "createPostLinks" to={'/forum/' + params.category +'/createPost/'}>Create Post</Link>

    </div>

</div>
  )
}


export default Forum;