import axios from "axios";
import React from "react";
import './LoginForm.css';

export class LoginForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      user: [],
        userName:"",
        userPassword: "",
    };
  }
     HandleSubmit = () => {
      if(this.state.userName === "solera@solera.com" && this.state.userPassword === "bootcamp2") { 
                  localStorage.setItem('userName', this.state.userName)
                  localStorage.setItem('isLoggedIn', "isLoggedIn")
      } 
};
  render = () => {
    return (
    
       <div className="loginForm">
      <form action="/" onSubmit={() => this.HandleSubmit()}>
        <h1 class = "Loginform">Login Form</h1> 
        
        <label for="userName">User name:</label>
        <input
          type="text"
          id="userName"
          name="userName"
          onChange={(e) => this.setState({ userName: e.target.value })}
        ></input>

        <label for="userPassword">Password:</label>
        <input
          type="password"
          id="userPassword"
          name={this.state._iDesc}
          onChange={(e) => this.setState({ userPassword: e.target.value })}
        ></input>

        <input
        id="submitLogin"
          type="submit"
          value="Submit"
        ></input>
      </form>
      </div>
    );
  };
}
export default LoginForm;
