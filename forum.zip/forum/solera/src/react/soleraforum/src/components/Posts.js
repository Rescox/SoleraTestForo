import './Posts.css';
import { Routes, Route, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';
import imagen from './img/1.jpg'

function Posts() {
  const [post, setPost] = useState([]);

    const params = useParams();

    const getPost = async () => {
      const  {data}  = await axios.get("http://localhost:8080/api/posts/one/" + params.postid);
      setPost(data)

    };

    useEffect(() => {        
      getPost();
    }, []);

  return (
    <div>
    <h2>{post.title}</h2>
    
    <p>
      {post.postbody}
    </p>
    <img width='50%' height='50%' src={imagen}></img>
    </div>
  )
}

export default Posts;