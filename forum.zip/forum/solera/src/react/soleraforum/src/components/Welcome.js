import React from 'react';
import './Welcome.css'

class Welcome extends React.Component{
    render() {

        return (
            <div className='welcomeH1'>
                <h1> Welcome</h1>
                
            </div>
              
        )
}};
export default Welcome;