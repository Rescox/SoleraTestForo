import axios from "axios";
import React, { useEffect, useState } from "react";
import './CreatePost.css';
import { Link, useParams } from "react-router-dom";


function CreatePost() {

  const [post, setPost] = useState([]);
  const [posttitle, setPosttile] = useState("")
  const [postCategory, setPostCategory] = useState("")
  const [postimageurl, setPostimageurl] = useState("")
  const [postdescription, setpostdescription] = useState("")
  const [Bannedword, setBannedword] = useState("")
  const [bool, setBool] = useState(false)
  const [hidden, setHidden] = useState("")

  const params = useParams();



  
  const getPost = async () => {
    const {data} = await axios.get("http://localhost:8080/api/posts/" + params.category);
    setPost(data);
  };

  
  
   
  const descriptionVisible = () => {    
    console.log(posttitle)
    for(var i=0;i<post.length;i++)
    {
        
        if(post[i].title === posttitle )    {
          console.log("Ogial");
          setBool(true)
          setHidden("hidden");   
        }  
              
        else
          setHidden("visible")  
          setBool(false)
 
    }
  }

    
  
   const HandleSubmit = e => {
        e.preventDefault();
        const post = {

        title:posttitle,
        category:postCategory,
        postbody:postdescription,
        imgurl:"imagen"

      }
      console.log(post);
      axios.post('http://localhost:8080/api/posts',  post )
        .then(res=>{
        console.log(res.data);
        
      }).catch(e => {
        console.log(e);
    });
};

  const checkBannedword = () => {
    return true;
  };

useEffect(() => {        
  getPost();
}, []);
 




    return (
       
        <div className="CreatePost">
          <h1 className = "CreatePostText">Create new post</h1> 
        <form onSubmit={(e) => HandleSubmit(e)}>
          

        
          <label className = "Labelnewpost" for="posttitle">Post title:</label>
          <input className = "Title"
            type="text"
            id="posttitle"
            name="posttitle"
            onChange={(e) =>{ setPosttile(e.target.value );descriptionVisible()}}
            ></input>

          <label className = "Labelnewpost" for="postCategory">Category</label>
          
        
        <div>
          <label className = "Labelnewpost" for="description">Description:</label>
          <input className = "InputPostDesc"
            type="text"
            id="description"
            name="description"
            onChange={(e) => setpostdescription(e.target.value)}
          ></input>

         
        </div>
          <input className = "Submitform"
            type="submit"
            value="Submit"
          ></input>
        </form>
        </div>
          );                      
  };
export default CreatePost;
