
import '../App.css';
import './FooterForo.css';

function FooterForo() {
  return (
    <div>
      <div className = "Footer">              
      </div> 
    </div>
  )
}

export default FooterForo;