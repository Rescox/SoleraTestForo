import {createContext} from 'react'

export const QuestionContext = createContext(null);