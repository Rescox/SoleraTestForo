import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class QuestionarySelenium {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Raul.Escribano\\Documents\\Selenium\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("http://localhost:3000/");
        
        driver.findElement(By.xpath("//input[@id='formQuestion']")).sendKeys("1");
        driver.findElement(By.xpath("//input[@id='submit']")).click();     
        Thread.sleep(1000);
        Select select = new Select(driver.findElement(By.xpath("//select[@id='formQuestion']")));
        select.selectByIndex(2);
        driver.findElement(By.xpath("//input[@id='submit']")).click(); 
        Thread.sleep(1000); 
        driver.findElement(By.xpath("//input[@id='formQuestion']")).sendKeys("1");
        driver.findElement(By.xpath("//input[@id='submit']")).click();     
        Thread.sleep(1000); 
        driver.findElement(By.xpath("//input[@id='formQuestion']")).sendKeys("1");
        driver.findElement(By.xpath("//input[@id='submit']")).click();     
        Thread.sleep(1000); 
        driver.findElement(By.xpath("//input[@id='formQuestion']")).sendKeys("1");
        driver.findElement(By.xpath("//input[@id='submit']")).click();     
        Thread.sleep(1000);
        }        
}

/*
 * Primer Test
 * driver.get("https://login.yahoo.com/");
        driver.findElement(By.xpath("//input[@id='login-username']")).sendKeys("Testtttttttt");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@id='login-signin']")).click(); 
 */

/* Segundo test
 * driver.get("https://accounts.lambdatest.com/register");
        driver.findElement(By.xpath("//input[@id='name']")).sendKeys("Testtttttttt");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@id='email']")).sendKeys("test@gmail.com");
        driver.findElement(By.xpath("//input[@id='userpassword']")).sendKeys("4234234234");
        Thread.sleep(5000);

        driver.findElement(By.xpath("//select[@id='country_code']")).sendKeys("Oman(+968)");
        driver.findElement(By.xpath("//input[@id='phone']")).sendKeys("4321234");

        Thread.sleep(5000);

        driver.findElement(By.xpath("//button[@data-testid='signup-button']")).click();
        System.out.println("Selenium Webdriver Script in Chrome");
        driver.close();

 */