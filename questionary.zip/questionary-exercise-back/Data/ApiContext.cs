﻿using Microsoft.EntityFrameworkCore;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Data
{
    public class ApiContext : DbContext
    {
    }
}
