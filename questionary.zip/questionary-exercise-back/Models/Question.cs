﻿namespace questionary_exercise_back.Models
{
    public class Question
    {
        public int Id { get; set; }
        public string QuestionText { get; set; }

        public string AnswerType { get; set; }
        public string Options { get; set; }
    }
}
