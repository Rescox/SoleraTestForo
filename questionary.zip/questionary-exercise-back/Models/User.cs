﻿namespace questionary_exercise_back.Models
{
    public class User
    {
        public int Id;
        public string Name { get; set; }
    }
}
