﻿namespace questionary_exercise_back.Models
{
    public class UserAnswer
    {
        public int Id;
        public int IdQuestion { get; set; }
        public int IdUser { get; set; }
        public int IdQuestionary { get; set; }
        public string? Answer { get; set; }
    }
}
