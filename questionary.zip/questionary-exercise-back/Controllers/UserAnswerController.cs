﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using questionary_exercise_back.Models;
using questionary_exercise_back.Repositories;

namespace questionary_exercise_back.Controllers
{

    [Route("api/userAnswer")]
    [ApiController]
    public class UserAnswerController : ControllerBase
    {
        private readonly iUserAnswerRepository _userAnswerRespository;
        public UserAnswerController(iUserAnswerRepository userAnswerRespository)
        {
            _userAnswerRespository = userAnswerRespository;
        }

        [HttpGet("getAllUserAnswers")]
        public async Task<IActionResult> GetAllUserAnswers()
        {
            var answer = await _userAnswerRespository.GetAllUserAnswers();
            Console.WriteLine(answer);
            return Ok(answer);
        }

        [HttpGet("getUserAnswerById/{id}")]
        public async Task<IActionResult> GetUserAnswer(int id)
        {
            return Ok(await _userAnswerRespository.GetUserAnswer(id));
        }

        [HttpPost("createUserAnswer/")]
        public async Task<IActionResult> CreateUserAnswer([FromBody] UserAnswer userAnswer)
        {
            if (userAnswer == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var created = await _userAnswerRespository.AddUserAnswer(userAnswer);
            return Created("created", created);
        }

        [HttpPut("updateUserAnswer/{id}")]
        public async Task<IActionResult> UpdateQuestionary([FromBody] UserAnswer userAnswer)
        {
            if (userAnswer == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _userAnswerRespository.UpdateUserAnswer(userAnswer);
            return NoContent();
        }

        [HttpDelete("deleteUserAnswer/{id}")]
        public async Task<IActionResult> DeleteUserAnswer(int id)
        {
            await _userAnswerRespository.RemoveUserAnswer(id);
            return NoContent();
        }
    }



    [Route("api/question")]
    [ApiController]
    public class QuestionController : ControllerBase
    {
        private readonly iQuestionRepository _questionRespository;
        public QuestionController(iQuestionRepository questionRespository)
        {
            _questionRespository = questionRespository;
        }

        [HttpGet("getAllQuestions")]
        public async Task<IActionResult> GetAllQuestions()
        {
            var answer = await _questionRespository.GetAllQuestions();
            Console.WriteLine(answer);
            return Ok(answer);
        }

        [HttpGet("getQuestionById/{id}")]
        public async Task<IActionResult> GetQuestion(int id)
        {
            return Ok(await _questionRespository.GetQuestion(id));
        }

        [HttpPost("createQuestion/")]
        public async Task<IActionResult> CreateUserAnswer([FromBody] Question question)
        {
            if (question == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var created = await _questionRespository.AddQuestion(question);
            return Created("created", created);
        }

        [HttpPut("updateQuestion/{id}")]
        public async Task<IActionResult> UpdateQuestion([FromBody] Question question)
        {
            if (question == null) return BadRequest();
            if (!ModelState.IsValid) return BadRequest(ModelState);
            await _questionRespository.UpdateQuestion(question);
            return NoContent();
        }

        [HttpDelete("deleteQuestion/{id}")]
        public async Task<IActionResult> DeleteQuestion(int id)
        {
            await _questionRespository.RemoveQuestion(id);
            return NoContent();
        }
    }




    //[Route("api/user")]
    //[ApiController]
    //public class UserController : ControllerBase
    //{
    //    private readonly iUserRepository _questionRespository;
    //    public UserController(iUserRepository questionRespository)
    //    {
    //        _questionRespository = questionRespository;
    //    }

    //    [HttpGet("getAllQuestions")]
    //    public async Task<IActionResult> GetAllQuestions()
    //    {
    //        var answer = await _questionRespository.GetAllQuestions();
    //        Console.WriteLine(answer);
    //        return Ok(answer);
    //    }

    //    [HttpGet("getQuestionById/{id}")]
    //    public async Task<IActionResult> GetQuestion(int id)
    //    {
    //        return Ok(await _questionRespository.GetQuestion(id));
    //    }

    //    [HttpPost("createQuestion/{id}")]
    //    public async Task<IActionResult> CreateUserAnswer([FromBody] Question question)
    //    {
    //        if (question == null) return BadRequest();
    //        if (!ModelState.IsValid) return BadRequest(ModelState);
    //        var created = await _questionRespository.AddQuestion(question);
    //        return Created("created", created);
    //    }

    //    [HttpPut("updateQuestion/{id}")]
    //    public async Task<IActionResult> UpdateQuestion([FromBody] Question question)
    //    {
    //        if (question == null) return BadRequest();
    //        if (!ModelState.IsValid) return BadRequest(ModelState);
    //        await _questionRespository.UpdateQuestion(question);
    //        return NoContent();
    //    }

    //    [HttpDelete("deleteQuestion/{id}")]
    //    public async Task<IActionResult> DeleteQuestion(int id)
    //    {
    //        await _questionRespository.RemoveQuestion(id);
    //        return NoContent();
    //    }
    //}
}
