﻿using Dapper;
using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public class UserAnswerRepository : iUserAnswerRepository
    {
        private readonly MySQLConfiguration _connectionString;
        public UserAnswerRepository(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }


        public Task<IEnumerable<UserAnswer>> GetAllUserAnswers()
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM useranswers";
            return db.QueryAsync<UserAnswer>(sql, new { });
        }

        public Task<UserAnswer> GetUserAnswer(int id)
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM useranswers WHERE id = @Id ";
            return db.QueryFirstOrDefaultAsync<UserAnswer>(sql, new { Id = id });
        }

        public async Task<bool> AddUserAnswer(UserAnswer userAnswer)
        {
            var db = dbConnection();
            var sql = @" INSERT INTO useranswers(idQuestion, idUser, idQuestionary, answer) 
                        VALUES(@IdQuestion, @IdUser, @IdQuestionary, @Answer) ";
            var result = await db.ExecuteAsync(sql, new { userAnswer.IdQuestionary, userAnswer.IdQuestion, userAnswer.IdUser, userAnswer.Answer});
            return result > 0;
        }

        public async Task<bool> RemoveUserAnswer(int id)
        {
            var db = dbConnection();
            var sql = @"DELETE FROM useranswers WHERE id = @Id";
            var result = await db.ExecuteAsync(sql, new { Id = id});
            return result > 0;
        }

        public async Task<bool> UpdateUserAnswer(UserAnswer userAnswer)
        {
            var db = dbConnection();
            var sql = @" UPDATE useranswers SET idQuestionary = @IdQuestionary, idQuestion= @IdQuestion, idUser= @IdUser, answer = @Answer WHERE id=@Id";
            var result = await db.ExecuteAsync(sql, new { userAnswer.IdQuestionary, userAnswer.IdQuestion, userAnswer.IdUser, userAnswer.Answer });
            return result > 0;
        }
    }
}
