﻿using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public interface iQuestionRepository
    {
        Task<IEnumerable<Question>> GetAllQuestions();
        Task<Question> GetQuestion(int id);
        Task<bool> AddQuestion(Question item);
        Task<bool> RemoveQuestion(int id);
        Task<bool> UpdateQuestion(Question item);
    }
}