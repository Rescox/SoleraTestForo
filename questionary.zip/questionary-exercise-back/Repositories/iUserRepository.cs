﻿using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public interface iUserRepository
    {
        Task<IEnumerable<User>> GetAllUsers();
        Task<User> GetUser(int id);
        Task<bool> AddUser(User user);
        Task<bool> RemoveUser(User user);
        Task<bool> UpdateUser(User user);
    }
}