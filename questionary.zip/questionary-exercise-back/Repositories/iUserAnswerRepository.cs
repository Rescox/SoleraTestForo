﻿using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public interface iUserAnswerRepository
    {
        Task<IEnumerable<UserAnswer>> GetAllUserAnswers();
        Task<UserAnswer> GetUserAnswer(int id);
        Task<bool> AddUserAnswer(UserAnswer userAnswer);
        Task<bool> RemoveUserAnswer(int id);
        Task<bool> UpdateUserAnswer(UserAnswer uuestionary);
    }
}
