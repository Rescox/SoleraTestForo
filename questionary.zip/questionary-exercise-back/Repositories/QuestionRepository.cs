﻿using Dapper;
using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public class QuestionRepository : iQuestionRepository
    {
        private readonly MySQLConfiguration _connectionString;
        public QuestionRepository(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }

        public async Task<bool> AddQuestion(Question item)
        {
            var db = dbConnection();
            var sql = @" INSERT INTO questions(questionText, answerType, options) 
                        VALUES(@QuestionText, @AnswerType, @Options) ";
            var result = await db.ExecuteAsync(sql, new { item.QuestionText, item.AnswerType, item.Options });
            return result > 0;
        }

        public Task<IEnumerable<Question>> GetAllQuestions()
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM questions";
            return db.QueryAsync<Question>(sql, new { });
        }

        public Task<Question> GetQuestion(int id)
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM questions WHERE id = @Id ";
            return db.QueryFirstOrDefaultAsync<Question>(sql, new { Id = id });
        }

        public async Task<bool> RemoveQuestion(int id)
        {
            var db = dbConnection();
            var sql = @"DELETE FROM questions WHERE id = @Id";
            var result = await db.ExecuteAsync(sql, new { Id = id });
            return result > 0;
        }

        public async Task<bool> UpdateQuestion(Question item)
        {
            var db = dbConnection();
            var sql = @" UPDATE questions SET questionText = @QuestionText, answerType = @AnswerType, options = @Options WHERE id=@Id";
            var result = await db.ExecuteAsync(sql, new { item.QuestionText, item.AnswerType, item.Options});
            return result > 0;
        }
    }
}
