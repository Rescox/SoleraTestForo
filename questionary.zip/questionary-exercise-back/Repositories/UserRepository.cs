﻿using Dapper;
using MySql.Data.MySqlClient;
using questionary_exercise_back.Data;
using questionary_exercise_back.Models;

namespace questionary_exercise_back.Repositories
{
    public class UserRepository : iUserRepository
    {
        private readonly MySQLConfiguration _connectionString;
        public UserRepository(MySQLConfiguration connectionString)
        {
            _connectionString = connectionString;
        }
        protected MySqlConnection dbConnection()
        {
            return new MySqlConnection(_connectionString.ConnectionString);
        }
        public async Task<bool> AddUser(User user)
        {
            var db = dbConnection();
            var sql = @" INSERT INTO users(name) 
                        VALUES(@Name) ";
            var result = await db.ExecuteAsync(sql, new { user.Name });
            return result > 0;
        }

        public Task<IEnumerable<User>> GetAllUsers()
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM users";
            return db.QueryAsync<User>(sql, new { });
        }

        public Task<User> GetUser(int id)
        {
            var db = dbConnection();
            var sql = @" SELECT * FROM users WHERE id = @Id ";
            return db.QueryFirstOrDefaultAsync<User>(sql, new { Id = id });
        }

        public async Task<bool> RemoveUser(User user)
        {
            var db = dbConnection();
            var sql = @"DELETE FROM users WHERE id = @Id";
            var result = await db.ExecuteAsync(sql, new { Id = user.Id });
            return result > 0;
        }

        public async Task<bool> UpdateUser(User user)
        {
            var db = dbConnection();
            var sql = @" UPDATE users SET name = @Name WHERE id=@Id";
            var result = await db.ExecuteAsync(sql, new { user.Name });
            return result > 0;
        }
    }
}
